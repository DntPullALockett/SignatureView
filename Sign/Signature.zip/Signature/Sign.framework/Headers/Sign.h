//
//  Sign.h
//  Sign
//
//  Created by Sharad Goyal on 20/08/18.
//  Copyright © 2018 Sharad Goyal. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Sign.
FOUNDATION_EXPORT double SignVersionNumber;

//! Project version string for Sign.
FOUNDATION_EXPORT const unsigned char SignVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Sign/PublicHeader.h>

